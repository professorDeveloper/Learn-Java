package record_learn.task2;

public class App {
    public static void main(String[] args) {
        User usr = new User();
        usr.showInfo();
    }
}
