package polymorphism.task1;

public class Main {
    public static void main(String[] args) {
        Figure figure = new Figure();
        figure.perimeter(3, 4, 5);
        figure.perimeter(5);
        figure.perimeter(2,4);
    }
}
