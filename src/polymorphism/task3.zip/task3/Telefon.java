package polymorphism.task3;

public class Telefon extends Texnika{
    public void work() {
        System.out.println("Telefon works on telegram");
    }
}
