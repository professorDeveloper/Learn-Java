package polymorphism.task3;

public class Mashina extends Texnika {
    public void work() {
        System.out.println("Mashina working");
    }
}
