package polymorphism.task3;

public class Telivizor extends Texnika{
    @Override
    public void work() {
        System.out.println("Telivizor works on Yoshlar channel");
    }

}
