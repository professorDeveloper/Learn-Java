package polymorphism.task3;

public class Texnika {
    public void work(){
        System.out.println("Texnika working");
    }

    public void turnOff(){
        System.out.println("Texnika turned off");
    }

    public void turnOn(){
        System.out.println("Texnika turned on");
    }
}
