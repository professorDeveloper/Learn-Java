package polymorphism.task4;

public class Animal {
    public void live(){
        System.out.println("Animal live");
    }
    public void eat(){
        System.out.println("Animal eat");
    }
}
