package module3.lesson.generics.task2;

public class Cat extends Animal {

    Cat(String petName, String color) {
        super(color, petName);
    }

}
