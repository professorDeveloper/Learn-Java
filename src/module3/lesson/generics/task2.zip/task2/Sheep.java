package module3.lesson.generics.task2;

public class Sheep extends Animal {
    Sheep(String petName, String color) {
        super(color, petName);
    }
}
