package module3.lesson.generics.task2;

public class Animal {
    String color;
    String name;

    public Animal(String color, String name) {
        this.color = color;
        this.name = name;
    }
}
