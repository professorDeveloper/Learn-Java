package module3.lesson.generics.task2;

public class Dog extends Animal {

    Dog(String petName, String color) {
        super(color,petName);
    }
}
