package module3.lesson.generics.task2;

public class Horse extends Animal {

    Horse(String name, String color) {
        super(color, name);

    }
}
