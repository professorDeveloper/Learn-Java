package module3.lesson.exceptions.tasks.task3;

public class Main {
    public static void main(String[] args) {
        Home home = new Home("Red", 0, 10, "Azamov");
    }
}
