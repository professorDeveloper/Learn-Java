package module3.lesson.exceptions.tasks.task1;

import java.util.Date;

public class ProgrammingLanguage {
    String name;
    String owner;
    Date releaseDate;

    public ProgrammingLanguage(String name, String owner, Date releaseDate) {
        this.name = name;
        this.owner = owner;
        this.releaseDate = releaseDate;
    }
}

// 1.