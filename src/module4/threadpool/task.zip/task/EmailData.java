package module4.threadpool.task;
record EmailData(String to, String subject, String body) {
}