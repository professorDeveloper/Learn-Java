package module4.threadlocal.localThreadTask;

public class ShoppingCartHolder {


}
