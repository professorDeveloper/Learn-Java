package lesson_enum.task1;

public enum Gender {
    MALE,FEMALE
}
