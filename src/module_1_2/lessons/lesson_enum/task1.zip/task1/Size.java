package lesson_enum.task1;

public enum Size {
    S,M,X,XL
}

