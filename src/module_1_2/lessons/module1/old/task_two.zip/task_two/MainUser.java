package task_two;
import task_two.User;
class MainUser {
    public static void main(String[] args) {
        User user = new User("Khusan", "Azamov", 19, "+998943017410", false);

        String name = user.getIsm();
        String familya = user.getFamilya();
        int age = user.getAge();
        String phoneNumber = user.getPhoneNumber();
        boolean isMale = user.isMale();

        System.out.println("Ismi: " + name + " Familya: " + familya + " yoshi: " + age + " telefoni raqami: " + phoneNumber + " Jinsi: " + isMale);
    }
}
