package task_four;

public class Main {
    public static void main(String[] args) {
        Pen pen = new Pen(10, 1);
        pen.click();
        pen.write("Hello World!");
    }
}
