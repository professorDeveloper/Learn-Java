package marker_interface.learn.task3;

public class Spark extends Vehicle {
}
