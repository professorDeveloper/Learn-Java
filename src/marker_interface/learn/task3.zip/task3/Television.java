package marker_interface.learn.task3;

public class Television extends Equipment{
}
