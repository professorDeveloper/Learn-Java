package marker_interface.learn.task3;

public abstract class Equipment implements Texnika{
}
