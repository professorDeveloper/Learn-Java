package lesson_one;

public class Main {
    public static void main(String[] args) {
        Rectangle rectangle = new Rectangle(10, 200);
        rectangle.calculate();
        rectangle.printResult();
    }
}
