package lesson_enum.task2;

public class Main {
    public static void main(String[] args) {
        Application application = Application.getInstance();
        application.run();
    }
}
