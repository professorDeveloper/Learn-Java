package interface_lesson.task2;

public interface Pet {
    void voice();
}
