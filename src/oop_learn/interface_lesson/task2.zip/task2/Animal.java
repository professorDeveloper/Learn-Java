package interface_lesson.task2;

public interface Animal {
    void live();
    void eat();
}
